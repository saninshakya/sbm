<?php
$data = $_POST;
print_r($data);
?>