<?php
// session_start();
// $_SESSION['chk'] = false;
unset($_SESSION['sbm_adminuser']);
unset($_SESSION['sbm_adminuser_id']);
echo ("<script type=\"text/javascript\">window.location=\"\home.php\"</script>");
?>
