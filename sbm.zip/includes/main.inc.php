<div class="container-fluid">
<div class="row">
	<div class="continent">
	  <div class="col-xs-2"><a href="index.php?page=country&continent=asia">ASIA</a></div>
	  <div class="col-xs-3"><a href="index.php?page=country&continent=america">AMERICA</a></div>
	  <div class="col-xs-2"><a href="index.php?page=country&continent=australia">AUSTRALIA</a></div>
	  <div class="col-xs-3"><a href="index.php?page=country&continent=africa">AFRICA</a></div>
	  <div class="col-xs-2"><a href="index.php?page=country&continent=europe">EUROPE</a></div>
	</div>
</div>
</div>


